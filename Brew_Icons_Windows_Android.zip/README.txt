Brew icon assets
================

Windows/
- Brew.ico: multi-resolution ICO (16, 24, 32, 48, 64, 128, 256 px)
- Brew_<size>x<size>.png: standalone PNGs for common app/UI sizes

Android/res/
- mipmap-mdpi/ic_launcher.png: 48x48
- mipmap-hdpi/ic_launcher.png: 72x72
- mipmap-xhdpi/ic_launcher.png: 96x96
- mipmap-xxhdpi/ic_launcher.png: 144x144
- mipmap-xxxhdpi/ic_launcher.png: 192x192

Android/adaptive/
- ic_launcher_foreground.png and ic_launcher_background.png: separate-layer adaptive-icon assets (432x432 px, corresponding to 108 dp at xxxhdpi)
- ic_launcher_full_432.png: full icon as one image
- play_store_icon_512.png: 512x512 icon for store/listing use

Notes:
- The adaptive foreground here is the full-bleed artwork; run it through Android Studio's Image Asset tool (or scale it to ~66% on a transparent canvas) to respect the safe zone before shipping, as done for the assets actually bundled in android/app/src/main/res.
- For production Android projects, configure adaptive layers in res/mipmap-anydpi-v26/ic_launcher.xml as appropriate for your min/target SDK.
- For Windows MSIX/WinUI packaging, additional manifest-specific scale and theme assets may be required. Brew.ico is suitable for common desktop/WPF/Win32 icon use.
